# EAGLE EDUCATION — Firebase Owner Panel

Firebase-powered Owner Panel enabled.

## Features
- Firebase Email/Password Owner Login
- Cloud video upload
- Cloud PDF/TXT notes upload
- Firestore content metadata
- Student-side cloud content listing
- Video playback from Firebase Storage
- Notes open/download from Firebase Storage
- Owner delete content
- Local demo password removed

## Before building
Configure `app/src/main/assets/firebase-config.js`, publish `firestore.rules` and `storage.rules`, and create the Owner user in Firebase Authentication.

See `FIREBASE_SETUP_HINDI.md` for the complete setup steps.

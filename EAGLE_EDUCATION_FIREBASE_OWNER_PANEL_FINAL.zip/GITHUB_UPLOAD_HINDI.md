# EAGLE EDUCATION — GitHub Upload Guide

इस ZIP को extract करने पर **EagleEducationAndroid folder के अंदर की सारी files/folders**
repository की ROOT में upload करें — `EagleEducationAndroid` नाम का extra wrapper folder
न बनाएं।

Root में ये दिखना चाहिए:
- app/
- build.gradle
- settings.gradle
- gradle.properties
- .github/workflows/android.yml
- firebase-config.js (यह app/src/main/assets/ के अंदर है)
- firestore.rules
- storage.rules

Firebase चलाने के लिए:
1. Firebase Console में Authentication > Email/Password enable करें.
2. Firestore Database और Storage enable करें.
3. Web App बनाकर उसकी config `app/src/main/assets/firebase-config.js` में डालें.
4. `firestore.rules` और `storage.rules` में अपना Owner email रखें.
5. GitHub Actions में Build Eagle Education APK चलाएं.

सुरक्षा: Owner password APK/HTML में hard-code न करें; Firebase Authentication का उपयोग करें.

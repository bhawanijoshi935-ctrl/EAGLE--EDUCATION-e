# EAGLE EDUCATION — Firebase Owner Panel Setup

इस version में Owner Panel Firebase Authentication + Cloud Firestore + Firebase Storage का उपयोग करता है।

## 1. Firebase project बनाएं
1. Firebase Console खोलें: https://console.firebase.google.com/
2. नया project बनाएं, जैसे `eagle-education`.
3. Project में **Web app** जोड़ें (`</>` icon).
4. Firebase द्वारा दिया गया config कॉपी करें।
5. `app/src/main/assets/firebase-config.js` में `YOUR_*` values की जगह अपना config डालें।

## 2. Owner Authentication
Firebase Console → Authentication → Sign-in method → **Email/Password** enable करें।

फिर Authentication → Users → **Add user** से Owner का email/password बनाएं।

उदाहरण:
- Email: `owner@example.com`
- Password: मजबूत password रखें

## 3. Firestore
Firebase Console → Firestore Database → Create database.

फिर `firestore.rules` में `YOUR_OWNER_EMAIL` को उसी Owner email से बदलें और rules publish करें।

इस app में collection अपने-आप बनेगी:
`content`

हर document में title, notes, fileName, mimeType, storagePath, downloadUrl और createdAt सेव होंगे।

## 4. Storage
Firebase Console → Storage → Get started.

`storage.rules` में `YOUR_OWNER_EMAIL` को Owner email से बदलें और rules publish करें।

Uploaded files `content/` folder में जाएंगे।

## 5. Android APK build
GitHub में पूरा project push करें और:
Actions → Build Eagle Education APK → Run workflow

## 6. Owner login
App खोलें → Owner Panel → Firebase Owner email + password डालें.

अब Owner:
- Video upload कर सकता है
- PDF/TXT notes upload कर सकता है
- Title/description दे सकता है
- Content delete कर सकता है

Upload के बाद content Firebase cloud में रहेगा और सभी students के app में दिखाई देगा।

## सुरक्षा
Owner password को HTML/JavaScript में hard-code नहीं किया गया है। Authentication Firebase पर है। Firestore/Storage write access केवल `YOUR_OWNER_EMAIL` वाले authenticated user को rules के अनुसार मिलता है।

Production में Owner email को एक dedicated account रखें और मजबूत password इस्तेमाल करें।
